#include <Arduino.h>
#include "serial_manager.h"
#include "commands.h"
#include "pins.h"


#include "motors.h"



// ===============================================
// =============== Motor instances ===============
// ===============================================
Motor motorFL(0, PWM_LEFT_FRONT,  IN1_LEFT_FRONT,  IN2_LEFT_FRONT);   // Front Left
Motor motorFR(1, PWM_RIGHT_FRONT, IN1_RIGHT_FRONT, IN2_RIGHT_FRONT);  // Front Right
Motor motorRL(2, PWM_LEFT_REAR,   IN1_LEFT_REAR,   IN2_LEFT_REAR);    // Rear Left
Motor motorRR(3, PWM_RIGHT_REAR,  IN1_RIGHT_REAR,  IN2_RIGHT_REAR);   // Rear Right

// MotorDriver orchestrates the four motors. Pass pointers to the motor instances.
//MotorDriver driver(&motorFL, &motorFR, &motorRL, &motorRR);
int32_t pwmFL = 0, pwmFR = 0, pwmRL = 0, pwmRR = 0;
unsigned long lastMotorCommand = 0;




// ===============================================
// ====== Serial configuration and managers ======
// ===============================================
constexpr unsigned long TIMEOUT_MS_ESP = 50;
constexpr unsigned long TIMEOUT_MS_TEENY = 10;
constexpr uint8_t MAX_PAYLOAD_SIZE = 32;
constexpr int RX2_PIN = RX2_PIN_ESP_TO_TEENSY;
constexpr int TX2_PIN = TX2_PIN_ESP_TO_TEENSY;
constexpr unsigned long SERIAL_BAUD = 115200;

// SerialManager instances:
SerialManager PI_serialManager(Serial, TIMEOUT_MS_ESP, MAX_PAYLOAD_SIZE);
SerialManager TEENSY_serialManager2(Serial2, TIMEOUT_MS_TEENY, MAX_PAYLOAD_SIZE);

// ===============================================
// ============ Encoder configuration ============
// ===============================================
constexpr uint32_t ENCODER_PERIOD_MS = 10;
uint32_t lastEncoderRequestMs = 0;
uint32_t lastSuccesfulEncoderRequestMs = 0;





void setup() {
    Serial.begin(SERIAL_BAUD);
    while (!Serial) {}

    Serial2.begin(115200, SERIAL_8N1, RX2_PIN, TX2_PIN);
    lastMotorCommand=millis();
}

void loop() {

    //Serial.printf("NEW LOOP @ %d\n", millis());
    uint8_t commandType;
    uint8_t payload[MAX_PAYLOAD_SIZE];
    uint8_t payloadLength;
    uint8_t receivedChecksum;

    uint8_t commandType_Teensy;
    uint8_t payload_Teensy[MAX_PAYLOAD_SIZE];
    uint8_t payloadLength_Teensy;
    uint8_t receivedChecksum_Teensy;

    CommandError error = CommandError::Timeout;
    CommandError errorT = CommandError::Timeout;

    if (Serial.available()) {
        error = PI_serialManager.readCommand(commandType, payload, payloadLength, receivedChecksum);
    }

    if ((millis() - lastSuccesfulEncoderRequestMs) >= ENCODER_PERIOD_MS) {
        // send a CMD_ENCODER request with no payload (adjust if your protocol expects something else)

        TEENSY_serialManager2.sendCommand(CMD_ENCODER, nullptr, 0);

        lastEncoderRequestMs = millis();
        delay(1);

        if (Serial2.available()) {
            errorT = TEENSY_serialManager2.readCommand(commandType_Teensy, payload_Teensy, payloadLength_Teensy, receivedChecksum_Teensy);
        }


        if (errorT == CommandError::None) {
            lastSuccesfulEncoderRequestMs = lastEncoderRequestMs;
            //Serial.printf("PROCESSED_MESSAGE @ %d\n", millis());

            switch(commandType_Teensy){
                case CMD_STATUS:
                {
                    {
                        uint8_t combinedPayload[MAX_PAYLOAD_SIZE];
                        uint8_t combinedLength = payloadLength_Teensy;
                        if (combinedLength > MAX_PAYLOAD_SIZE) combinedLength = MAX_PAYLOAD_SIZE; // safety
                        // copy original payload (up to available space)
                        for (uint8_t i = 0; i < combinedLength; ++i) combinedPayload[i] = payload_Teensy[i];

                        // attempt to append timestamp (4 bytes)
                        if ((uint8_t)(payloadLength_Teensy + 4) <= MAX_PAYLOAD_SIZE) {
                            uint32_t ts = lastEncoderRequestMs;
                            combinedPayload[combinedLength + 0] = (uint8_t)(ts & 0xFF);
                            combinedPayload[combinedLength + 1] = (uint8_t)((ts >> 8) & 0xFF);
                            combinedPayload[combinedLength + 2] = (uint8_t)((ts >> 16) & 0xFF);
                            combinedPayload[combinedLength + 3] = (uint8_t)((ts >> 24) & 0xFF);
                            combinedLength += 4;
                        } 

                        PI_serialManager.sendCommand(CMD_STATUS, combinedPayload, combinedLength);
                    }
                    
                    break;
                }

                default:
                    break;    
            }
        }
    }


    if (error == CommandError::None) {
        switch(commandType){
            case CMD_MOTOR_TICK: {

                lastMotorCommand=millis();

                auto readInt16LE_raw = [&](uint8_t idx)->int16_t {
                        uint16_t lo = payload[idx];
                        uint16_t hi = payload[idx + 1];
                        return (int16_t)(lo | (hi << 8));
                };
                
                if(payloadLength!=8){break;}

                pwmFL = readInt16LE_raw(0);
                pwmFR = readInt16LE_raw(2);
                pwmRL = readInt16LE_raw(4);
                pwmRR = readInt16LE_raw(6);
 
                break;
            }

            default:
                break;

        };
    }


    if((millis() - lastMotorCommand) > 1000){
        pwmFL = 0;
        pwmFR = 0;
        pwmRL = 0;
        pwmRR = 0;
        motorFL.brake();
        motorFR.brake();
        motorRL.brake();
        motorRR.brake();
        lastMotorCommand=millis();
    }
    else{
        motorFL.setSpeed(pwmFL);
        motorFR.setSpeed(pwmFR);
        motorRL.setSpeed(pwmRL);
        motorRR.setSpeed(pwmRR);
    }
}


