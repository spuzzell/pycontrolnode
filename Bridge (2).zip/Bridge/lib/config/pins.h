
//##################################################################################################
//                                             MOTOR CONTROL
//##################################################################################################

#define PWM_LEFT_FRONT  33
#define IN1_LEFT_FRONT  26
#define IN2_LEFT_FRONT  14

#define PWM_RIGHT_FRONT 22
#define IN1_RIGHT_FRONT 19
#define IN2_RIGHT_FRONT 4

#define PWM_LEFT_REAR   32
#define IN1_LEFT_REAR   25
#define IN2_LEFT_REAR   27

#define PWM_RIGHT_REAR  23
#define IN1_RIGHT_REAR  21
#define IN2_RIGHT_REAR  18

//##################################################################################################
//                                             UART PINS
//##################################################################################################

#define RX2_PIN_ESP_TO_TEENSY       16
#define TX2_PIN_ESP_TO_TEENSY       17