#pragma once

#include "motor_types.h"
#include "motor_base.h"

class MotorDriver {
public:
  MotorDriver(Motor* frontLeft, Motor* frontRight, Motor* rearLeft, Motor* rearRight);

  void setMotorSpeed(MotorID id, int pwm);
  void setAllMotorSpeeds(int flPwm, int frPwm, int rlPwm, int rrPwm);
  void brakeAll();

private:
  Motor* motors_[4];
  Direction currentDirection_[4];
  Direction newDirection_[4];
  bool directionChanged_;
};