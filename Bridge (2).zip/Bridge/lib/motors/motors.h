#pragma once
#ifndef MOTOR_H
#define MOTOR_H

#include <Arduino.h>

enum class Direction {
  FORWARD,
  REVERSE
};

class Motor {
public:
  Motor(int pwmChannel, int enablePin, int forwardPin, int reversePin);

  void setSpeed(int pwm);
  void brake();


private:
  void sendMotorCommand();
  int pwmChannel_;
  int enablePin_;
  int forwardPin_;
  int reversePin_;
  int pendingPwm_ = 0;
  Direction currentDirection_ = Direction::FORWARD;
};

#endif