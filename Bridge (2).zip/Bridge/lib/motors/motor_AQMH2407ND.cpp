#include "motor_AQMH2407ND.h"

AQMH2407NDNMotor::AQMH2407NDNMotor(int pwmChannel, int enablePin, int forwardPin, int reversePin)
  : pwmChannel_(pwmChannel), enablePin_(enablePin), forwardPin_(forwardPin), reversePin_(reversePin), currentDirection_(Direction::FORWARD) {
  pinMode(enablePin_, OUTPUT);
  pinMode(forwardPin_, OUTPUT);
  pinMode(reversePin_, OUTPUT);

  ledcSetup(pwmChannel_, 20000, 8);
  ledcAttachPin(enablePin_, pwmChannel_);
  
  digitalWrite(forwardPin_, LOW);
  digitalWrite(reversePin_, LOW);
  ledcWrite(pwmChannel_, 0);

  pendingPwm_ = 0;
}

void AQMH2407NDNMotor::setSpeed(int pwm) {
    pwm = constrain(pwm, -255, 255);
    // Determine new direction
    Direction newDirection = (pwm >= 0) ? Direction::FORWARD : Direction::REVERSE;

    pwm = abs(pwm);
    pendingPwm_ = pwm;

    if (pwm == 0) {
        brake();
        return;
    }

    currentDirection_ = newDirection;
    sendMotorCommand();
}

void AQMH2407NDNMotor::brake() {
  // Force both direction pins low (IN1 = 0, IN2 = 0)
  ledcWrite(pwmChannel_, 0);
  digitalWrite(forwardPin_, LOW);
  digitalWrite(reversePin_, LOW);
}

void AQMH2407NDNMotor::sendMotorCommand(){
    ledcWrite(pwmChannel_, pendingPwm_);
    
    // Set direction pins based on the table
    if (currentDirection_ == Direction::FORWARD) {
        digitalWrite(forwardPin_, HIGH);
        digitalWrite(reversePin_, LOW);
    } else {
        digitalWrite(forwardPin_, LOW);
        digitalWrite(reversePin_, HIGH);
    }
}



