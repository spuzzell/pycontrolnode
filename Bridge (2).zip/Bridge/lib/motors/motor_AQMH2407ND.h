#pragma once
#ifndef MOTOR_AQMH2407ND_H
#define MOTOR_AQMH2407ND_H

#include <Arduino.h>
#include "motor_base.h"

class AQMH2407NDNMotor : public Motor {
public:
  AQMH2407NDNMotor(int pwmChannel, int enablePin, int forwardPin, int reversePin);

  void setSpeed(int pwm) override;
  void brake() override;


private:
  void sendMotorCommand();
  int pwmChannel_;
  int enablePin_;
  int forwardPin_;
  int reversePin_;
  int pendingPwm_ = 0;
  Direction currentDirection_ = Direction::FORWARD;
};

#endif