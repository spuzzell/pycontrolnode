#include "motors.h"

Motor::Motor(int pwmChannel, int enablePin, int forwardPin, int reversePin)
  : pwmChannel_(pwmChannel), enablePin_(enablePin), forwardPin_(forwardPin), reversePin_(reversePin), currentDirection_(Direction::FORWARD) {
  pinMode(enablePin_, OUTPUT);
  pinMode(forwardPin_, OUTPUT);
  pinMode(reversePin_, OUTPUT);

  ledcSetup(pwmChannel_, 20000, 8);
  ledcAttachPin(enablePin_, pwmChannel_);
  
  digitalWrite(forwardPin_, LOW);
  digitalWrite(reversePin_, LOW);
  ledcWrite(pwmChannel_, 0);


}

void Motor::setSpeed(int pwm) {
    pwm = constrain(pwm, -255, 255);
    // Determine new direction
    Direction newDirection = (pwm >= 0) ? Direction::FORWARD : Direction::REVERSE;

    pwm = abs(pwm);

    if (pwm == 0) {
        brake();
        return;
    }

    if (currentDirection_ == Direction::FORWARD) {
        digitalWrite(forwardPin_, HIGH);
        digitalWrite(reversePin_, LOW);
    } else {
        digitalWrite(forwardPin_, LOW);
        digitalWrite(reversePin_, HIGH);
    }

    ledcWrite(pwmChannel_, pwm);
}

void Motor::brake() {
  // Force both direction pins low (IN1 = 0, IN2 = 0)
  ledcWrite(pwmChannel_, 0);
  digitalWrite(forwardPin_, LOW);
  digitalWrite(reversePin_, LOW);
}




