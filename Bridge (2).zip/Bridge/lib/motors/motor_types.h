#pragma once

enum class MotorID {
  FRONT_LEFT,
  FRONT_RIGHT,
  REAR_LEFT,
  REAR_RIGHT
};

constexpr int kMotorCount = 4;

enum class Direction {
  FORWARD,
  REVERSE
};
