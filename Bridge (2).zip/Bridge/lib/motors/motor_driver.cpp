#include "motor_driver.h"
#include <Arduino.h>

MotorDriver::MotorDriver(Motor* frontLeft, Motor* frontRight, Motor* rearLeft, Motor* rearRight) {
  motors_[(int)MotorID::FRONT_LEFT] = frontLeft;
  motors_[(int)MotorID::FRONT_RIGHT] = frontRight;
  motors_[(int)MotorID::REAR_LEFT] = rearLeft;
  motors_[(int)MotorID::REAR_RIGHT] = rearRight;

  // Initialize each motor's direction to a default value, e.g., FORWARD
  currentDirection_[(int)MotorID::FRONT_LEFT] = Direction::FORWARD;
  currentDirection_[(int)MotorID::FRONT_RIGHT] = Direction::FORWARD;
  currentDirection_[(int)MotorID::REAR_LEFT] = Direction::FORWARD;
  currentDirection_[(int)MotorID::REAR_RIGHT] = Direction::FORWARD;

}

void MotorDriver::setMotorSpeed(MotorID id, int pwm) {
  if (motors_[(int)id]) {
    motors_[(int)id]->setSpeed(pwm);
  }
}

void MotorDriver::setAllMotorSpeeds(int flPwm, int frPwm, int rlPwm, int rrPwm) {

  newDirection_[(int)MotorID::FRONT_LEFT] = (flPwm >= 0) ? Direction::FORWARD : Direction::REVERSE;
  newDirection_[(int)MotorID::FRONT_RIGHT] = (frPwm >= 0) ? Direction::FORWARD : Direction::REVERSE;
  newDirection_[(int)MotorID::REAR_LEFT] = (rlPwm >= 0) ? Direction::FORWARD : Direction::REVERSE;
  newDirection_[(int)MotorID::REAR_RIGHT] = (rrPwm >= 0) ? Direction::FORWARD : Direction::REVERSE;

  // If any direction changes, brake all motors first
  directionChanged_ = false;
  for (int i = 0; i < 4; ++i) {
    if (newDirection_[i] != currentDirection_[i]) {
      directionChanged_ = true;
      break;
    }
  }
  if (directionChanged_) {
    brakeAll();
    // Update current directions after braking
    for (int i = 0; i < 4; ++i) {
      currentDirection_[i] = newDirection_[i];
    }
    delay(10);
  }


  if (motors_[(int)MotorID::FRONT_LEFT]) {
    motors_[(int)MotorID::FRONT_LEFT]->setSpeed(flPwm);
  }

  if (motors_[(int)MotorID::FRONT_RIGHT]) {
    motors_[(int)MotorID::FRONT_RIGHT]->setSpeed(frPwm);
  }

  if (motors_[(int)MotorID::REAR_LEFT]) {
    motors_[(int)MotorID::REAR_LEFT]->setSpeed(rlPwm);
  }

  if (motors_[(int)MotorID::REAR_RIGHT]) {
    motors_[(int)MotorID::REAR_RIGHT]->setSpeed(rrPwm);
  }
}

void MotorDriver::brakeAll() {
  for (int i = 0; i < 4; ++i) {
    if (motors_[i]) {
      motors_[i]->brake();
    }
  }
}