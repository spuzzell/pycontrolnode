#pragma once

#include "motor_types.h"

class Motor {
public:
  virtual ~Motor() = default;

  // Set target speed immediately (range -255..255). Must exist.
  virtual void setSpeed(int pwm) = 0;

  // Immediate brake request.
  virtual void brake() = 0;

  
};