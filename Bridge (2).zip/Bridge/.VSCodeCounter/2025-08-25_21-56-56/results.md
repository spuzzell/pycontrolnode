# Summary

Date : 2025-08-25 21:56:56

Directory c:\\Users\\OLIVER\\Documents\\PlatformIO\\Projects\\Bridge

Total : 17 files,  808 codes, 174 comments, 244 blanks, all 1226 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| C++ | 13 | 535 | 122 | 188 | 845 |
| Python | 2 | 227 | 43 | 46 | 316 |
| Markdown | 1 | 42 | 0 | 8 | 50 |
| Ini | 1 | 4 | 9 | 2 | 15 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 17 | 808 | 174 | 244 | 1,226 |
| . (Files) | 1 | 4 | 9 | 2 | 15 |
| lib | 13 | 390 | 106 | 133 | 629 |
| lib\\config | 2 | 48 | 18 | 18 | 84 |
| lib\\controller | 2 | 33 | 4 | 25 | 62 |
| lib\\motors | 7 | 193 | 8 | 56 | 257 |
| lib\\motors (Files) | 6 | 151 | 8 | 48 | 207 |
| lib\\motors\\Docs | 1 | 42 | 0 | 8 | 50 |
| lib\\serial_manager | 2 | 116 | 76 | 34 | 226 |
| src | 1 | 187 | 16 | 63 | 266 |
| test_scripts_pc_side | 2 | 227 | 43 | 46 | 316 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)