# Details

Date : 2025-08-25 21:56:56

Directory c:\\Users\\OLIVER\\Documents\\PlatformIO\\Projects\\Bridge

Total : 17 files,  808 codes, 174 comments, 244 blanks, all 1226 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Bridge/lib/config/commands.h](/Bridge/lib/config/commands.h) | C++ | 34 | 12 | 11 | 57 |
| [Bridge/lib/config/pins.h](/Bridge/lib/config/pins.h) | C++ | 14 | 6 | 7 | 27 |
| [Bridge/lib/controller/controller.cpp](/Bridge/lib/controller/controller.cpp) | C++ | 14 | 0 | 10 | 24 |
| [Bridge/lib/controller/controller.h](/Bridge/lib/controller/controller.h) | C++ | 19 | 4 | 15 | 38 |
| [Bridge/lib/motors/Docs/readme.md](/Bridge/lib/motors/Docs/readme.md) | Markdown | 42 | 0 | 8 | 50 |
| [Bridge/lib/motors/motor\_AQMH2407ND.cpp](/Bridge/lib/motors/motor_AQMH2407ND.cpp) | C++ | 40 | 3 | 15 | 58 |
| [Bridge/lib/motors/motor\_AQMH2407ND.h](/Bridge/lib/motors/motor_AQMH2407ND.h) | C++ | 20 | 0 | 6 | 26 |
| [Bridge/lib/motors/motor\_base.h](/Bridge/lib/motors/motor_base.h) | C++ | 8 | 2 | 6 | 16 |
| [Bridge/lib/motors/motor\_driver.cpp](/Bridge/lib/motors/motor_driver.cpp) | C++ | 56 | 3 | 13 | 72 |
| [Bridge/lib/motors/motor\_driver.h](/Bridge/lib/motors/motor_driver.h) | C++ | 15 | 0 | 4 | 19 |
| [Bridge/lib/motors/motor\_types.h](/Bridge/lib/motors/motor_types.h) | C++ | 12 | 0 | 4 | 16 |
| [Bridge/lib/serial\_manager/serial\_manager.cpp](/Bridge/lib/serial_manager/serial_manager.cpp) | C++ | 84 | 21 | 20 | 125 |
| [Bridge/lib/serial\_manager/serial\_manager.h](/Bridge/lib/serial_manager/serial_manager.h) | C++ | 32 | 55 | 14 | 101 |
| [Bridge/platformio.ini](/Bridge/platformio.ini) | Ini | 4 | 9 | 2 | 15 |
| [Bridge/src/main.cpp](/Bridge/src/main.cpp) | C++ | 187 | 16 | 63 | 266 |
| [Bridge/test\_scripts\_pc\_side/Motor\_raw\_pwm\_test.py](/Bridge/test_scripts_pc_side/Motor_raw_pwm_test.py) | Python | 93 | 16 | 21 | 130 |
| [Bridge/test\_scripts\_pc\_side/Motor\_raw\_pwm\_test\_encoder.py](/Bridge/test_scripts_pc_side/Motor_raw_pwm_test_encoder.py) | Python | 134 | 27 | 25 | 186 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)