# ...existing code...
#!/usr/bin/env python3
import struct
import sys
import time

try:
    import serial
except ImportError:
    print("pyserial not found. Install with: pip install pyserial")
    sys.exit(1)

HEADER = 0xAA
CMD_MOTOR_RAW = 0x02

def crc8(data: bytes) -> int:
    crc = 0x00
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ 0x07) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc

def build_frame(cmd_type: int, payload: bytes = b"") -> bytes:
    body = bytes([HEADER, cmd_type & 0xFF, len(payload) & 0xFF]) + payload
    return body + bytes([crc8(body)])

def make_payload(fl: int, fr: int, rl: int, rr: int, use_int16: bool) -> bytes:
    vals = [fl, fr, rl, rr]
    if use_int16:
        if any(v < -32768 or v > 32767 for v in vals):
            raise ValueError("int16 values must be in range -32768..32767")
        return struct.pack("<hhhh", *vals)
    else:
        if any(v < 0 or v > 255 for v in vals):
            raise ValueError("uint8 values must be in range 0..255")
        return struct.pack("BBBB", *vals)  # unsigned uint8


def main():
    # ===== Edit your settings here =====
    PORT = "COM3"         # e.g., "COM5" on Windows
    BAUD = 115200

    # Time between sending different PWM sets (seconds)
    INTERVAL_S = 1.0

    # If REPEAT_COUNT = 0 -> loop forever
    REPEAT_COUNT = 0

    USE_INT16 = True     # False => send 4x 8-bit, True => send 4x 16-bit (little-endian)
    

    # Define the series of PWM signals to run through.
    # Each item is (FL, FR, RL, RR). Values must match the chosen integer width/signedness.
    if USE_INT16:
        SEQUENCES = [
            (255, 0, 0, 0),
            #(-128, -128, -128, -128),
            #(0, 0, 0, 0),
            #(128, 128, 128, 128),
            #(254, 254, 254, 254),
            #(0, -255, 0, -255),      # was (128,0,128,0) in uint8
            #(-255, 0, -255, 0),      # was (0,128,0,128)
            #(254, -255, -255, 254),  # was (255,0,0,255)
        ]
    else:
        SEQUENCES = [
            (0, 0, 0, 0),
            (64, 64, 64, 64),
            (128, 128, 128, 128),
            (192, 192, 192, 192),
            (255, 255, 255, 255),
            (128, 0, 128, 0),      # example pattern
            (0, 128, 0, 128),
            (255, 0, 0, 255),
        ]
    # ===================================

    try:
        ser = serial.Serial(PORT, BAUD, timeout=0.1, write_timeout=0.1)
    except Exception as e:
        print(f"Failed to open port {PORT}: {e}")
        sys.exit(1)

    # Optional: give device a moment after opening the port
    time.sleep(0.2)

    mode_str = ("int16" if USE_INT16
                else
                "int8")
    print(f"Starting sequence on {PORT} (mode={mode_str}), interval={INTERVAL_S}s, repeat={'∞' if REPEAT_COUNT==0 else REPEAT_COUNT}")
    print(f"Sequence length: {len(SEQUENCES)}")

    try:
        iteration = 0
        while True:
            iteration += 1
            for idx, vals in enumerate(SEQUENCES):
                FL, FR, RL, RR = vals
                try:
                    payload = make_payload(FL, FR, RL, RR, USE_INT16)
                except ValueError as ve:
                    print(f"Invalid values at sequence index {idx}: {ve}")
                    ser.close()
                    return

                frame = build_frame(CMD_MOTOR_RAW, payload)
                ser.write(frame)
                ser.flush()
                print(f"[{iteration}] Sent seq {idx}: {[FL, FR, RL, RR]}")
                time.sleep(INTERVAL_S)

            if REPEAT_COUNT != 0:
                REPEAT_COUNT -= 1
                if REPEAT_COUNT == 0:
                    print("Completed requested repeats.")
                    break

    except KeyboardInterrupt:
        print("\nStopped by user.")
    finally:
        ser.close()

if __name__ == "__main__":
    main()
