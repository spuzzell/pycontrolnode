# ...existing code...
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
# ...existing code...

def load_and_clean(csv_path: Path, max_abs=1e7):
    df = pd.read_csv(csv_path)
    # ensure numeric
    for c in df.columns:
        df[c] = pd.to_numeric(df[c], errors='coerce')
    # remove crazy outliers (replace with NaN)
    num_cols = df.select_dtypes(float).columns
    df[num_cols] = df[num_cols].where(df[num_cols].abs() <= max_abs)
    return df

# ...existing code...
def plot(df: pd.DataFrame, csv_path: Path = None, smooth: int = 0, out: Path = None):
    t = df['time_s']
    wheels = ['velFL', 'velFR', 'velRL', 'velRR']

    # choose a style that exists on the system (fallback to default)
    preferred = ['seaborn-darkgrid', 'seaborn', 'seaborn-muted', 'ggplot', 'classic']
    for s in preferred:
        if s in plt.style.available:
            plt.style.use(s)
            break

    fig, ax = plt.subplots(figsize=(11,6))
    for w in wheels:
        if w in df.columns:
            y = df[w].interpolate().rolling(smooth, min_periods=1).mean() if smooth>1 else df[w]
            ax.plot(t, y, label=w)
    if 'target' in df.columns:
        ax.plot(t, df['target'], '--', color='k', label='target')
    ax.set_xlabel('time (s)')
    ax.set_ylabel('velocity / command')
    title = csv_path.name if csv_path is not None else 'PID log'
    ax.set_title(title)
    ax.legend(loc='best')
    ax.set_xlim(left=t.min(), right=t.max())
    fig.tight_layout()
    if out:
        fig.savefig(out, dpi=200)
    else:
        plt.show()
# ...existing code...

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Plot PID log CSV')
    parser.add_argument('csv', nargs='?', default=r'c:\Users\OLIVER\Documents\PlatformIO\Projects\Bridge\test_scripts_pc_side\pid_log_.csv', help='path to CSV')
    parser.add_argument('--smooth', '-s', type=int, default=0, help='rolling smooth window (samples). 0 = none')
    parser.add_argument('--save', '-o', help='output PNG path (if omitted show)')
    args = parser.parse_args()

    csv_path = Path(args.csv)
    df = load_and_clean(csv_path)
    out_path = Path(args.save) if args.save else None
    plot(df, csv_path=csv_path, smooth=args.smooth, out=out_path)