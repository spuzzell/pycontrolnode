# ...existing code...
#!/usr/bin/env python3
import struct
import sys
import time
import matplotlib.pyplot as plt
from collections import deque

try:
    import serial
except ImportError:
    print("pyserial not found. Install with: pip install pyserial")
    sys.exit(1)

HEADER = 0xAA
CMD_MOTOR_RAW = 0x01

def crc8(data: bytes) -> int:
    crc = 0x00
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ 0x07) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc

# new: parse frames from a running buffer
def parse_frames_from_buffer(buf: bytearray):
    frames = []
    header_b = bytes([HEADER])
    while True:
        idx = buf.find(header_b)
        if idx == -1:
            # no header present -> drop buffer
            buf.clear()
            break
        if idx > 0:
            # discard leading garbage
            del buf[:idx]
        # need at least header + cmd + len + crc
        if len(buf) < 4:
            break
        cmd = buf[1]
        length = buf[2]
        total_len = 4 + length  # header(1)+cmd(1)+len(1)+payload(length)+crc(1)
        if len(buf) < total_len:
            # wait for more bytes
            break
        frame = bytes(buf[:total_len])
        # verify checksum
        if crc8(frame[:-1]) == frame[-1]:
            payload = frame[3:-1]  # payload slice
            frames.append((cmd, payload))
            del buf[:total_len]
        else:
            # bad checksum -> discard this header and search again
            del buf[0]
    return frames

def build_frame(cmd_type: int, payload: bytes = b"") -> bytes:
    body = bytes([HEADER, cmd_type & 0xFF, len(payload) & 0xFF]) + payload
    return body + bytes([crc8(body)])

def make_payload(fl: int, fr: int, rl: int, rr: int) -> bytes:
    vals = [fl, fr, rl, rr]

    if any(v < -32768 or v > 32767 for v in vals):
        raise ValueError("int16 values must be in range -32768..32767")
    return struct.pack("<hhhh", *vals)


def Send_pwm(PWMFL,PWMFR,PWMRL,PWMRR,ser):
    try:
        payload = make_payload(PWMFL, PWMFR, PWMRL, PWMRR)
    except ValueError as ve:
        print(f"Invalid PWM values: {ve}")
        ser.close()
        return

    frame = build_frame(CMD_MOTOR_RAW, payload)
    ser.write(frame)
    ser.flush()

def estimate_pwm_from_setpoint(setpoint_cps: float,
                               counts_per_rev: int = 2096,
                               no_load_rpm: float = 83.0,
                               pwm_max: int = 255) -> int:
    # setpoint_cps: encoder counts per second (signed for direction)
    sign = -1 if setpoint_cps < 0 else 1
    cps = abs(setpoint_cps)
    # gearbox RPM (if no_load_rpm refers to gearbox output). If no_load_rpm is motor RPM, set gear_ratio=131.
    rpm_set = (cps / counts_per_rev) * 60.0
    # if provided no_load_rpm is motor shaft, divide by gear_ratio to get gearbox no-load rpm
    frac = min(max(rpm_set / no_load_rpm, 0.0), 1.0)
    pwm = int(round(frac * pwm_max))
    return sign * min(max(pwm, -pwm_max), pwm_max)



class PID:
    def __init__(self, kp: float, ki: float = 0.0, kd: float = 0.0,
                 out_min: int = -32768, out_max: int = 32767,
                 int_min: float = None, int_max: float = None):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.out_min = out_min
        self.out_max = out_max
        self.int_min = int_min if int_min is not None else out_min
        self.int_max = int_max if int_max is not None else out_max
        self._integral = 0.0
        self._last_error = 0.0
        self._last_out = 0

    def reset(self):
        self._integral = 0.0
        self._last_error = 0.0
        self._last_out = 0

    def update(self, setpoint: float, measurement: float, dt: float) -> int:
        if dt is None or dt <= 0:
            return int(self._last_out)
        error = setpoint - measurement
        derivative = (error - self._last_error) / dt

        # tentative integral (don't commit yet)
        integral_candidate = self._integral + error * dt
        # compute tentative output using tentative integral
        out_tent = self.kp * error + self.ki * integral_candidate + self.kd * derivative

        # anti-windup: only accept the integral update if tentative output is not saturating
        if self.out_min <= out_tent <= self.out_max:
            self._integral = max(self.int_min, min(self.int_max, integral_candidate))
        # else: skip updating integral (prevents wind-up). Optionally allow limited back-calculation here.

        out = self.kp * error + self.ki * self._integral + self.kd * derivative

        # clamp output
        if out < self.out_min:
            out = self.out_min
        elif out > self.out_max:
            out = self.out_max

        self._last_error = error
        self._last_out = int(round(out))
        return self._last_out








def main():
    # ===== Edit your settings here =====
    PORT = "COM3"         # e.g., "COM5" on Windows
    BAUD = 115200
    setpoint = 2096

    last5FL = deque(maxlen=5)
    last5FR = deque(maxlen=5)
    last5RL = deque(maxlen=5)
    last5RR = deque(maxlen=5)

    lastnow = deque(maxlen=5)

    errorFL = deque(maxlen=5)
    errorFR = deque(maxlen=5)
    errorRL = deque(maxlen=5)
    errorRR = deque(maxlen=5)

    idx = 0

    # previous encoder values for velocity calculation
    prev_encFL = prev_encFR = prev_encRL = prev_encRR = 0
    prev_time = 0


    try:
        ser = serial.Serial(PORT, BAUD, timeout=0.1, write_timeout=0.1)
    except Exception as e:
        print(f"Failed to open port {PORT}: {e}")
        sys.exit(1)

    # Optional: give device a moment after opening the port
    time.sleep(2)
    ser.reset_input_buffer()
    print(f"Starting sequence on {PORT}")

    # running buffer for incoming bytes
    rx_buf = bytearray()
    start = time.time()

    COUNTS_PER_REV = 2096
    TIMESTAMP_UNITS = "ms"  # set to "us" if 'now' is in microseconds
    tt = 0
    t_rel = 0.0
    t_log, cpsFL_log, cpsFR_log, cpsRL_log, cpsRR_log = [], [], [], [], []

    try:
        while True:
            try:

                if tt<time.time():
                    Send_pwm(0,0,0,500,ser)
                    tt = time.time()+1

                """line = ser.readline()   # bytes ending with \r\n from Serial.println
                if line:
                    print(line.decode("utf-8", errors="replace").strip())"""


                data = ser.read(ser.in_waiting) if ser.in_waiting else b""
                if not data:
                    continue
                rx_buf.extend(data)

                frames = parse_frames_from_buffer(rx_buf)
                if not frames:
                    continue

                for _, payload in frames:
                    if len(payload) >= 16:
                        encFL_new, encFR_new, encRL_new, encRR_new, now =  struct.unpack_from("<iiiiI", payload, 0)
                        encFL_new=encFL_new/4
                        encFR_new = encFR_new/4
                        encRL_new = encRL_new/4
                        encRR_new = encRR_new/4

                        if prev_time == 0:
                            prev_encFL, prev_encFR, prev_encRL, prev_encRR = encFL_new, encFR_new, encRL_new, encRR_new
                            prev_time = now
                            continue

                        # compute dt in seconds with uint32 wrap-around
                        dt_ticks = (now - prev_time) & 0xFFFFFFFF
                        dt_s = dt_ticks / (1000.0 if TIMESTAMP_UNITS == "ms" else 1_000_000.0)
                        if dt_s <= 0:
                            continue

                        # counts delta
                        dFL = encFL_new - prev_encFL
                        dFR = encFR_new - prev_encFR
                        dRL = encRL_new - prev_encRL
                        dRR = encRR_new - prev_encRR

                        cpsFL = dFL / dt_s
                        cpsFR = dFR / dt_s
                        cpsRL = dRL / dt_s
                        cpsRR = dRR / dt_s

                        last5FL.append(cpsFL)
                        last5FR.append(cpsFR)
                        last5RL.append(cpsRL)
                        last5RR.append(cpsRR)

                        avgFL = sum(last5FL) / len(last5FL) if last5FL else 0.0
                        avgFR = sum(last5FR) / len(last5FR) if last5FR else 0.0
                        avgRL = sum(last5RL) / len(last5RL) if last5RL else 0.0
                        avgRR = sum(last5RR) / len(last5RR) if last5RR else 0.0

                        t_rel += dt_s
                        t_log.append(t_rel)
                        cpsFL_log.append(avgFL)
                        cpsFR_log.append(avgFR)
                        cpsRL_log.append(avgRL)
                        cpsRR_log.append(avgRR)

                        print(f"dt={dt_s*1000:.1f} ms | CPS FL:{cpsFL:8.2f} FR:{cpsFR:8.2f} RL:{cpsRL:8.2f} RR:{cpsRR:8.2f}")
                        # update previous
                        prev_encFL, prev_encFR, prev_encRL, prev_encRR = encFL_new, encFR_new, encRL_new, encRR_new
                        prev_time = now




            except Exception as e:
                print(f"Serial read error: {e}")




    except KeyboardInterrupt:
        ser.close()
        print("\nStopped by user.")
        finish = time.time()
        print(f"Total run time: {finish - start}")

        try:
            if t_log:
                plt.figure(figsize=(10, 6))
                plt.plot(t_log, cpsFL_log, label="FL")
                plt.plot(t_log, cpsFR_log, label="FR")
                plt.plot(t_log, cpsRL_log, label="RL")
                plt.plot(t_log, cpsRR_log, label="RR")
                plt.xlabel("Time [s]")
                plt.ylabel("Counts per second (CPS)")
                plt.title("Wheel CPS vs Time")
                plt.grid(True, alpha=0.3)
                plt.legend()
                plt.tight_layout()
                plt.ylim(-3000, 3000)
                plt.show()
            else:
                print("No samples collected; nothing to plot.")
        except Exception as plot_err:
            print(f"Plotting failed: {plot_err}")

    finally:
        ser.close()

if __name__ == "__main__":
    main()
