# ...existing code...
#!/usr/bin/env python3
import struct
import sys
import time

try:
    import serial
except ImportError:
    print("pyserial not found. Install with: pip install pyserial")
    sys.exit(1)

HEADER = 0xAA
CMD_MOTOR_RAW = 0x02

def crc8(data: bytes) -> int:
    crc = 0x00
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ 0x07) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc

# new: parse frames from a running buffer
def parse_frames_from_buffer(buf: bytearray):
    frames = []
    header_b = bytes([HEADER])
    while True:
        idx = buf.find(header_b)
        if idx == -1:
            # no header present -> drop buffer
            buf.clear()
            break
        if idx > 0:
            # discard leading garbage
            del buf[:idx]
        # need at least header + cmd + len + crc
        if len(buf) < 4:
            break
        cmd = buf[1]
        length = buf[2]
        total_len = 4 + length  # header(1)+cmd(1)+len(1)+payload(length)+crc(1)
        if len(buf) < total_len:
            # wait for more bytes
            break
        frame = bytes(buf[:total_len])
        # verify checksum
        if crc8(frame[:-1]) == frame[-1]:
            payload = frame[3:-1]  # payload slice
            frames.append((cmd, payload))
            del buf[:total_len]
        else:
            # bad checksum -> discard this header and search again
            del buf[0]
    return frames

def build_frame(cmd_type: int, payload: bytes = b"") -> bytes:
    body = bytes([HEADER, cmd_type & 0xFF, len(payload) & 0xFF]) + payload
    return body + bytes([crc8(body)])

def make_payload(fl: int, fr: int, rl: int, rr: int) -> bytes:
    vals = [fl, fr, rl, rr]

    if any(v < -32768 or v > 32767 for v in vals):
        raise ValueError("int16 values must be in range -32768..32767")
    return struct.pack("<hhhh", *vals)


def Send_pwm(PWMFL,PWMFR,PWMRL,PWMRR,ser):
    try:
        payload = make_payload(PWMFL, PWMFR, PWMRL, PWMRR)
    except ValueError as ve:
        print(f"Invalid values at sequence index {idx}: {ve}")
        ser.close()
        return

    frame = build_frame(CMD_MOTOR_RAW, payload)
    ser.write(frame)
    ser.flush()








def main():
    # ===== Edit your settings here =====
    PORT = "COM3"         # e.g., "COM5" on Windows
    BAUD = 115200

    # Time between sending different PWM sets (seconds)
    INTERVAL_S = 1.0


    SETPOINT = 2096

    # Define the series of PWM signals to run through.
    # Each item is (FL, FR, RL, RR). Values must match the chosen integer width/signedness.



    try:
        ser = serial.Serial(PORT, BAUD, timeout=0.1, write_timeout=0.1)
    except Exception as e:
        print(f"Failed to open port {PORT}: {e}")
        sys.exit(1)

    # Optional: give device a moment after opening the port
    time.sleep(0.2)


    print(f"Starting sequence on {PORT} (mode=int16), interval={INTERVAL_S}s")


    # running buffer for incoming bytes
    rx_buf = bytearray()

    try:
        while True:

            Send_pwm(PWMFL,PWMFR,PWMRL,PWMRR,ser)

            try:
                n = ser.in_waiting
                if n:
                    data = ser.read(n)
                    if data:
                        rx_buf.extend(data)
                        frames = parse_frames_from_buffer(rx_buf)
                        for cmd, payload in frames:
                            # if payload looks like 4x int32 little-endian, decode as encoders
                            if len(payload) >= 16:
                                encFL, encFR, encRL, encRR = struct.unpack_from("<iiii", payload, 0)

            except Exception as e:
                print(f"Serial read error: {e}")

                time.sleep(INTERVAL_S)



    except KeyboardInterrupt:
        print("\nStopped by user.")
    finally:
        ser.close()

if __name__ == "__main__":
    main()
