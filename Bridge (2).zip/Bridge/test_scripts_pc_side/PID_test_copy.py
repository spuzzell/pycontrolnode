# ...existing code...
#!/usr/bin/env python3
import struct
import sys
import time
import matplotlib.pyplot as plt
from collections import deque

try:
    import serial
except ImportError:
    print("pyserial not found. Install with: pip install pyserial")
    sys.exit(1)

HEADER = 0xAA
CMD_MOTOR_RAW = 0x02

def crc8(data: bytes) -> int:
    crc = 0x00
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 0x80:
                crc = ((crc << 1) ^ 0x07) & 0xFF
            else:
                crc = (crc << 1) & 0xFF
    return crc

# new: parse frames from a running buffer
def parse_frames_from_buffer(buf: bytearray):
    frames = []
    header_b = bytes([HEADER])
    while True:
        idx = buf.find(header_b)
        if idx == -1:
            # no header present -> drop buffer
            buf.clear()
            break
        if idx > 0:
            # discard leading garbage
            del buf[:idx]
        # need at least header + cmd + len + crc
        if len(buf) < 4:
            break
        cmd = buf[1]
        length = buf[2]
        total_len = 4 + length  # header(1)+cmd(1)+len(1)+payload(length)+crc(1)
        if len(buf) < total_len:
            # wait for more bytes
            break
        frame = bytes(buf[:total_len])
        # verify checksum
        if crc8(frame[:-1]) == frame[-1]:
            payload = frame[3:-1]  # payload slice
            frames.append((cmd, payload))
            del buf[:total_len]
        else:
            # bad checksum -> discard this header and search again
            del buf[0]
    return frames

def build_frame(cmd_type: int, payload: bytes = b"") -> bytes:
    body = bytes([HEADER, cmd_type & 0xFF, len(payload) & 0xFF]) + payload
    return body + bytes([crc8(body)])

def make_payload(fl: int, fr: int, rl: int, rr: int) -> bytes:
    vals = [fl, fr, rl, rr]

    if any(v < -32768 or v > 32767 for v in vals):
        raise ValueError("int16 values must be in range -32768..32767")
    return struct.pack("<hhhh", *vals)


def Send_pwm(PWMFL,PWMFR,PWMRL,PWMRR,ser):
    try:
        payload = make_payload(PWMFL, PWMFR, PWMRL, PWMRR)
    except ValueError as ve:
        print(f"Invalid PWM values: {ve}")
        ser.close()
        return

    frame = build_frame(CMD_MOTOR_RAW, payload)
    ser.write(frame)
    ser.flush()

def estimate_pwm_from_setpoint(setpoint_cps: float,
                               counts_per_rev: int = 2096,
                               no_load_rpm: float = 83.0,
                               pwm_max: int = 255) -> int:
    # setpoint_cps: encoder counts per second (signed for direction)
    sign = -1 if setpoint_cps < 0 else 1
    cps = abs(setpoint_cps)
    # gearbox RPM (if no_load_rpm refers to gearbox output). If no_load_rpm is motor RPM, set gear_ratio=131.
    rpm_set = (cps / counts_per_rev) * 60.0
    # if provided no_load_rpm is motor shaft, divide by gear_ratio to get gearbox no-load rpm
    frac = min(max(rpm_set / no_load_rpm, 0.0), 1.0)
    pwm = int(round(frac * pwm_max))
    return sign * min(max(pwm, -pwm_max), pwm_max)



class PID:
    def __init__(self, kp: float, ki: float = 0.0, kd: float = 0.0,
                 out_min: int = -32768, out_max: int = 32767,
                 int_min: float = None, int_max: float = None):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.out_min = out_min
        self.out_max = out_max
        self.int_min = int_min if int_min is not None else out_min
        self.int_max = int_max if int_max is not None else out_max
        self._integral = 0.0
        self._last_error = 0.0
        self._last_out = 0

    def reset(self):
        self._integral = 0.0
        self._last_error = 0.0
        self._last_out = 0

    def update(self, setpoint: float, measurement: float, dt: float) -> int:
        if dt is None or dt <= 0:
            return int(self._last_out)
        error = setpoint - measurement
        derivative = (error - self._last_error) / dt

        # tentative integral (don't commit yet)
        integral_candidate = self._integral + error * dt
        # compute tentative output using tentative integral
        out_tent = self.kp * error + self.ki * integral_candidate + self.kd * derivative

        # anti-windup: only accept the integral update if tentative output is not saturating
        if self.out_min <= out_tent <= self.out_max:
            self._integral = max(self.int_min, min(self.int_max, integral_candidate))
        # else: skip updating integral (prevents wind-up). Optionally allow limited back-calculation here.

        out = self.kp * error + self.ki * self._integral + self.kd * derivative

        # clamp output
        if out < self.out_min:
            out = self.out_min
        elif out > self.out_max:
            out = self.out_max

        self._last_error = error
        self._last_out = int(round(out))
        return self._last_out





def main():
    # ===== Edit your settings here =====
    PORT = "COM3"         # e.g., "COM5" on Windows
    BAUD = 115200

    # Time between sending different PWM sets (millisecond)
    INTERVAL_S = 0.02
    SETPOINT = [2096, 2096, 2096, 2096]

    pwmFL = pwmFR = pwmRL = pwmRR = 0


    # previous encoder values for velocity calculation
    prev_encFL = prev_encFR = prev_encRL = prev_encRR = None
    prev_time = None




    try:
        ser = serial.Serial(PORT, BAUD, timeout=0.1, write_timeout=0.1)
    except Exception as e:
        print(f"Failed to open port {PORT}: {e}")
        sys.exit(1)

    # Optional: give device a moment after opening the port
    time.sleep(0.2)

    print(f"Starting sequence on {PORT} (mode=int16), interval={INTERVAL_S}s")


    # running buffer for incoming bytes
    rx_buf = bytearray()

  
    times = []
    speedsFL, speedsFR, speedsRL, speedsRR = [], [], [], []
    target_vals = []
    first_frame = True

    last15_FL = deque(maxlen=15)
    last15_FR = deque(maxlen=15)
    last15_RL = deque(maxlen=15)
    last15_RR = deque(maxlen=15)



    try:
        while True:
            pwmFL = estimate_pwm_from_setpoint(SETPOINT[0])
            pwmFR = estimate_pwm_from_setpoint(SETPOINT[1])
            pwmRL = estimate_pwm_from_setpoint(SETPOINT[2])
            pwmRR = estimate_pwm_from_setpoint(SETPOINT[3])
            Send_pwm(pwmFL,pwmFR,pwmRL,pwmRR,ser)
            


            try:
                data = ser.read(ser.in_waiting) if ser.in_waiting else b""
                if not data:
                    continue
                rx_buf.extend(data)
                frames = parse_frames_from_buffer(rx_buf)
                if not frames:
                    continue

                for cmd, payload in frames:
                    if len(payload) >= 16:
                        encFL_new, encFR_new, encRL_new, encRR_new, now =  struct.unpack_from("<iiiiI", payload, 0)
                    
                    velFL = velFR = velRL = velRR = 0.0

                    if prev_time is not None:
                        dt_ms = now - prev_time
                        if dt_ms > 0:
                            dt = dt_ms / 1000.0
                            velFL = (encFL_new - prev_encFL) / dt
                            velFR = (encFR_new - prev_encFR) / dt
                            velRL = (encRL_new - prev_encRL) / dt
                            velRR = (encRR_new - prev_encRR) / dt

                    prev_encFL, prev_encFR, prev_encRL, prev_encRR = encFL_new, encFR_new, encRL_new, encRR_new
                    prev_time = now

                    last15_FL.append(velFL)
                    last15_FR.append(velFR)
                    last15_RL.append(velRL)
                    last15_RR.append(velRR)

                    avgFL = sum(last15_FL) / len(last15_FL) if last15_FL else 0.0
                    avgFR = sum(last15_FR) / len(last15_FR) if last15_FR else 0.0
                    avgRL = sum(last15_RL) / len(last15_RL) if last15_RL else 0.0
                    avgRR = sum(last15_RR) / len(last15_RR) if last15_RR else 0.0

                    print(f"SYS SPEEDS -> FL={velFL:.2f} FR={velFR:.2f} RL={velRL:.2f} RR={velRR:.2f} | "
                          f"AVG15 -> FL={avgFL:.2f} FR={avgFR:.2f} RL={avgRL:.2f} RR={avgRR:.2f} @ {now}")


            except Exception as e:
                print(f"Serial read error: {e}")

                time.sleep(INTERVAL_S)



    except KeyboardInterrupt:
        print("\nStopped by user.")

        import csv
        import os
        fname = os.path.join(os.getcwd(), f"pid_log_.csv")
        with open(fname, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["time_s", "velFL", "velFR", "velRL", "velRR", "target"])
            for row in zip(times, speedsFL, speedsFR, speedsRL, speedsRR, target_vals):
                writer.writerow(row)
        print(f"Saved log to {fname}")


    finally:
        ser.close()

if __name__ == "__main__":
    main()
